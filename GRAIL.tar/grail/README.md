# GRAIL
GRAIL, the awesome programming language!