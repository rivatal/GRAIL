make clean
rm *.ll
rm ./bin/final
rm ./bin/*.dat
